package com.example.applicationrftg;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URL;
import java.util.ArrayList;

public class ListefilmsActivity extends AppCompatActivity {

    private ProgressBar progress;
    private ListView liste;

    // adapte l'URL si besoin (context-path, port…)
    private static final String ENDPOINT = "http://10.0.2.2:8180/films";
    private static final String TOKEN = ""; // colle ton Bearer ici si nécessaire

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listefilm);

        progress = findViewById(R.id.progress);
        liste = findViewById(R.id.liste);

        try {
            new ListefilmsTask(this, TOKEN).execute(new URL(ENDPOINT));
        } catch (Exception e) {
            AfficherTexte("URL invalide : " + e.getMessage());
        }
    }

    public void showLoading(boolean show) {
        progress.setVisibility(show ? View.VISIBLE : View.GONE);
        progress.setIndeterminate(show);
    }

    public void AfficherTexte(String data) {
        ArrayList<String> lignes = new ArrayList<>();
        lignes.add(data);
        liste.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lignes));
    }

    // ✅ Version compatible Java 8 (cast classique, pas de pattern matching)
    public void AfficherJson(String json) {
        try {
            ArrayList<String> items = new ArrayList<>();
            Object root = new JSONTokener(json).nextValue();

            if (root instanceof JSONArray) {
                JSONArray arr = (JSONArray) root;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String titre = o.has("title") ? o.getString("title")
                            : o.has("titre") ? o.getString("titre")
                            : o.toString();
                    items.add(titre);
                }
            } else if (root instanceof JSONObject) {
                JSONObject o = (JSONObject) root;
                items.add(o.toString());
            } else {
                items.add(json);
            }

            liste.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items));
        } catch (Exception e) {
            AfficherTexte(json);
        }
    }
}



