package com.example.applicationrftg;

import android.os.AsyncTask;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ListefilmsTask extends AsyncTask<URL, Integer, String> {

    private final ListefilmsActivity screen;
    private final String bearerToken;

    public ListefilmsTask(ListefilmsActivity s, String token) {
        this.screen = s;
        this.bearerToken = token == null ? "" : token.trim();
    }

    @Override
    protected void onPreExecute() { screen.showLoading(true); }

    @Override
    protected String doInBackground(URL... urls) { return appelerServiceRestHttp(urls[0]); }

    @Override
    protected void onPostExecute(String resultat) {
        screen.showLoading(false);
        screen.AfficherJson(resultat);
    }

    private String appelerServiceRestHttp(URL urlAAppeler) {
        HttpURLConnection conn = null;
        StringBuilder sb = new StringBuilder();
        try {
            conn = (HttpURLConnection) urlAAppeler.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("User-Agent", System.getProperty("http.agent"));
            if (!bearerToken.isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + bearerToken);
            }
            int code = conn.getResponseCode();
            InputStream in = new BufferedInputStream(
                    code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream()
            );
            int c; while ((c = in.read()) != -1) sb.append((char) c);
            in.close();
        } catch (Exception e) {
            Log.d("mydebug", "HTTP error: " + e);
        } finally {
            if (conn != null) conn.disconnect();
        }
        return sb.toString();
    }
}


